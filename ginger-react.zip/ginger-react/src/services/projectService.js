import api from './api';

const API_URL = '/projects';

const getAllProjects = async () => {
    return await api.get(API_URL);
};

const createProject = async (project) => {
    return await api.post(API_URL, project);
};

const updateProject = async (id, project) => {
    return await api.put(`${API_URL}/${id}`, project);
};

const deleteProject = async (id) => {
    return await api.delete(`${API_URL}/${id}`);
};

export default {
    getAllProjects,
    createProject,
    updateProject,
    deleteProject
};
