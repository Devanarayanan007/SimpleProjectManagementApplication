import React, { useState, useEffect } from 'react';
import projectService from '../services/projectService';
import { Modal, Button, Form, Table, Row, Col, Card } from 'react-bootstrap';

const Project = () => {
    const [projects, setProjects] = useState([]);
    const [form, setForm] = useState({ name: '', description: '', status: 'Not Started' });
    const [showModal, setShowModal] = useState(false);
    const [editModal, setEditModal] = useState(false);
    const [projectName, setProjectName] = useState("");
    const [projectDescription, setProjectDescription] = useState("");
    const [projectStatus, setProjectStatus] = useState("");
    const [projectID, setProjectID] = useState("");

    useEffect(() => {
        fetchProjects();
    }, []);

    const fetchProjects = async () => {
        const res = await projectService.getAllProjects();
        setProjects(res.data);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm({ ...form, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await projectService.createProject(form);
        setForm({ name: '', description: '', status: 'Not Started' });
        fetchProjects();
        handleCloseModal();
    };

    const handleUpdate = async (id) => {
        const payload = { name: projectName, description: projectDescription, status: form.status };
        await projectService.updateProject(id, payload);
        fetchProjects();
    };

    const handleDelete = async (id) => {
        await projectService.deleteProject(id);
        fetchProjects();
    };

    const handleShowModal = () => setShowModal(true);
    const handleEditModal = (data) => {
        setProjectName(data.name);
        setProjectDescription(data.description);
        setProjectStatus(data.status);
        setProjectID(data._id);
        setEditModal(true);
    };
    const handleCloseModal = () => {
        setShowModal(false);
        setEditModal(false);
    };

    return (
        <div className="container mt-5">
            <Row>
                {projects.map((project) => (
                    <Col md={4} key={project._id} className="mb-3">
                        <Card>
                            <Card.Body>
                                <Card.Title>{project.name}</Card.Title>
                                <Card.Text>{project.description}</Card.Text>
                                <Card.Text>Status: {project.status}</Card.Text>
                                <Button variant="danger" onClick={() => handleDelete(project._id)}>Delete</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>
            <br />
            <br />
            <div className="d-flex justify-content-between mb-3">
                <h2>Projects</h2>
                <Button onClick={handleShowModal}>Create Project</Button>
            </div>
            <Table bordered>
                <thead>
                    <tr>
                        <th>Project Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {projects.map((project, index) => (
                        <tr key={index}>
                            <td style={{ width: "300px" }}>{project.name}</td>
                            <td style={{ width: "600px" }}>{project.description}</td>
                            <td style={{ width: "200px" }}>{project.status}</td>
                            <td style={{ width: "50px" }}>
                                <Button onClick={(e) => handleEditModal(project)}>Edit</Button>
                            </td>
                        </tr>
                    ))}
                    {projects && projects?.length === 0 && (
                        <tr className="text-center">
                            <td colSpan={12}>
                                <h4>No Record found.</h4>
                            </td>
                        </tr>
                    )}
                </tbody>
            </Table>

            <Modal show={showModal} onHide={handleCloseModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Create Project</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group>
                            <Form.Label>Project Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="name"
                                value={form.name}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Description</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="description"
                                value={form.description}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Status</Form.Label>
                            <Form.Control
                                as="select"
                                name="status"
                                value={form.status}
                                onChange={handleChange}
                            >
                                <option>Not Started</option>
                                <option>In Progress</option>
                                <option>Completed</option>
                            </Form.Control>
                        </Form.Group>
                        <br />
                        <Button type="submit">Add Project</Button>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={editModal} onHide={handleCloseModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit Project</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={() => handleUpdate(projectID)}>
                        <Form.Group>
                            <Form.Label>Project Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="name"
                                value={projectName}
                                onChange={handleChange}
                                disabled={true}
                            />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Description</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="description"
                                value={projectDescription}
                                onChange={handleChange}
                                disabled={true}
                            />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Status</Form.Label>
                            <Form.Control
                                as="select"
                                name="status"
                                value={form.status || projectStatus}
                                onChange={handleChange}
                            >
                                <option>Not Started</option>
                                <option>In Progress</option>
                                <option>Completed</option>
                            </Form.Control>
                        </Form.Group>
                        <br />
                        <Button type="submit">Edit Project</Button>
                    </Form>
                </Modal.Body>
            </Modal>
        </div>
    );
};

export default Project;
