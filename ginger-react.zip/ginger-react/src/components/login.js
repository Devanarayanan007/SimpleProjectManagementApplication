import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import authService from '../services/authService';
import "../assets/css/login.css";
import BackgroundImage from "../assets/images/loginBG.jpg";

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            await authService.login({ email, password });
            navigate('/dashboard');
        } catch (err) {
            setError('Invalid credentials, please try again.');
        }
    };

    return (
        <div className="sign-in__wrapper" style={{ backgroundImage: `url(${BackgroundImage})` }}>
            <Form className="shadow p-4 bg-white rounded" onSubmit={handleLogin}>
                <div className="h4 mb-2 text-center">Sign In</div>
                <Form.Group className="mb-2" controlId="username">
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                        type="email"
                        value={email}
                        placeholder="Email"
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </Form.Group>
                <Form.Group className="mb-2" controlId="password">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                        type="password"
                        value={password}
                        placeholder="Password"
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </Form.Group>
                <Button className="w-100" variant="primary" type="submit">
                    Log In
                </Button>
                {error && <Alert variant="danger">{error}</Alert>}
            </Form>
        </div>
    );
};

export default Login;
