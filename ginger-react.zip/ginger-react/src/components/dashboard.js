import React from 'react';
import { Container } from 'react-bootstrap';
import Project from './project';
import NavBar from './navbar';

const Dashboard = () => {
    return (
        <>
            <NavBar />
            <Container className="mt-2" >
                <Project />
            </Container>
        </>
    );
};

export default Dashboard;
